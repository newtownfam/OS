/* Bathroom.c tester */

#include "Bathroom.h"
#include <stdlib.h>
#include <stdio.h>

int main()
{

	/*struct br* brGlobal = (struct br *)malloc(sizeof(struct br));
	brGlobal->gender = -1;
	brGlobal->mCount = 0;
	brGlobal->fCount = 0;
	brGlobal->totalUsages = 0;
	brGlobal->vacantTime = 0;
	brGlobal->occupiedTime = 0;

	int male = 1;
	int female = 0;

	printf("GF: %d, MC: %d, FC: %d, TU, %d\n", brGlobal->gender, brGlobal->mCount, brGlobal->fCount, brGlobal->totalUsages);

	enter(brGlobal, male);
	printf("GF: %d, MC: %d, FC: %d, TU, %d\n", brGlobal->gender, brGlobal->mCount, brGlobal->fCount, brGlobal->totalUsages);

	enter(brGlobal, male);
	printf("GF: %d, MC: %d, FC: %d, TU, %d\n", brGlobal->gender, brGlobal->mCount, brGlobal->fCount, brGlobal->totalUsages);

	leave(brGlobal);
	printf("GF: %d, MC: %d, FC: %d, TU, %d\n", brGlobal->gender, brGlobal->mCount, brGlobal->fCount, brGlobal->totalUsages);

	enter(brGlobal, male);
	printf("GF: %d, MC: %d, FC: %d, TU, %d\n", brGlobal->gender, brGlobal->mCount, brGlobal->fCount, brGlobal->totalUsages);

	enter(brGlobal, female);
	printf("GF: %d, MC: %d, FC: %d, TU, %d\n", brGlobal->gender, brGlobal->mCount, brGlobal->fCount, brGlobal->totalUsages);

	leave(brGlobal);
	printf("GF: %d, MC: %d, FC: %d, TU, %d\n", brGlobal->gender, brGlobal->mCount, brGlobal->fCount, brGlobal->totalUsages);

	leave(brGlobal);
	printf("GF: %d, MC: %d, FC: %d, TU, %d\n", brGlobal->gender, brGlobal->mCount, brGlobal->fCount, brGlobal->totalUsages);

	leave(brGlobal);
	printf("GF: %d, MC: %d, FC: %d, TU, %d\n", brGlobal->gender, brGlobal->mCount, brGlobal->fCount, brGlobal->totalUsages);

	enter(brGlobal, female);
	printf("GF: %d, MC: %d, FC: %d, TU, %d\n", brGlobal->gender, brGlobal->mCount, brGlobal->fCount, brGlobal->totalUsages);

*/

	return 0;

}