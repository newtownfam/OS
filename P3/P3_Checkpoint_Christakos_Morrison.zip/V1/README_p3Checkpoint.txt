P3 Checkpoint
Peter Christakos
Andrew Morrison

To whom it may concern, 

	I honestly dont think anyone actually looks at the checkpoints so I don't think this is even necessary but what the hell. So this stuff we have works pretty well, we implemented locks and threads and everything. There are only a few compilation warnings for unused variables which we will fix once we implement statistics.  